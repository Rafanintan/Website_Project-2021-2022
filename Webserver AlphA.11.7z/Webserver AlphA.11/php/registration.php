<?php

session_start();

$con = mysqli_connect('localhost','root@localhost','3306');

mysqli_select_db($con,'userregistration');

$name=$_POST['user'];
$pass=$_POST['password'];
$mname=$_POST['prim_name'];
$sname=$_POST['sec_name'];
$cat=$_POST['category'];

$s = "select * from usertable where name = '$name'";

$result = mysqli_querry($con, $s);

$num = mysqli_num_rows($result);

if($num == 1)
{
    echo "username is taken";
}
else
{
    $reg = "insert into  usertable (username , password , prim_name , second_name , categor) values ('$name' , '$pass' , '$mname' , '$sname' , '$cat')";
    mysqli_querry($con , $reg);
    echo "Registration Sucess";
}

?>