<?php

session_start();

$con = mysqli_connect('localhost','root','');
if(!$con){
  
}
mysqli_select_db($con,'userregistration');




$name=$_POST['user'];
$pass=$_POST['password'];
$mname=$_POST['prim_name'];
$sname=$_POST['sec_name'];
$cat=$_POST['category'];


    $reg = "insert into  usertable (username , password , prim_name , second_name , categor) values ('$name' , '$pass' , '$mname' , '$sname' , '$cat')";
    mysqli_query($con , $reg);
    echo "Registration Sucess";


?>