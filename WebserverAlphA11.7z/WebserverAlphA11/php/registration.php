<?php

session_start();
header('Location:http://localhost/WebserverAlphA11/index.html');
$con = mysqli_connect('localhost','root','');
if(!$con){
  
}
mysqli_select_db($con,'userregistration');




$name=$_POST['user'];
$pass=$_POST['password'];
$mname=$_POST['prim_name'];
$sname=$_POST['sec_name'];
$cat=$_POST['category'];

$s= "select * from usertable where username = '$name'";
$result= mysqli_query($con,$s);
$num =$result->num_rows;
if($num ==1 )
{
    echo"Name Already Taken";
    header('Location:http://localhost/WebserverAlphA11/register.html');
}
else
{
    $reg = "insert into  usertable (username , password , prim_name , second_name , categor) values ('$name' , '$pass' , '$mname' , '$sname' , '$cat')";
    mysqli_query($con , $reg);
    header('Location:http://localhost/WebserverAlphA11/index.html');  
}



?>