<?php

session_start();
$con = mysqli_connect('localhost','root','');
if(!$con){
  
}
mysqli_select_db($con,'userregistration');




$name=$_POST['user'];
$pass=$_POST['password'];
$cat=$_POST['category'];

$s= "select * from usertable where username = '$name' && password = '$pass'";
$result= mysqli_query($con,$s);
$num =$result->num_rows;
if($num ==1 )
{
    $_SESSION['categor'] = $cat;
    $_SESSION2['categor'] = $cat;
    header('Location:http://localhost/WebserverAlphA11/index2.html');
}
else
{
    header('Location:http://localhost/WebserverAlphA11/sign_in.html');  
}



?>