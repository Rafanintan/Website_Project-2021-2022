<?php

session_start();

if($_SESSION2 == 'option1')
{
    header('location:http://localhost/WebserverAlphA11/permission_denied.html');
}
else
{
    header('location:http://localhost/WebserverAlphA11/add_announcement.html');
}





?>