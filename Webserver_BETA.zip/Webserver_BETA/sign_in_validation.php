<?php
session_start();
$con = mysqli_connect('localhost','root','');
if(!$con){
}
mysqli_select_db($con,'userregistration');
$name=$_POST['user'];
$pass=$_POST['password'];
$cat=$_POST['category'];
$fname=$_POST['fname'];
$sname=$_POST['sname'];
$s= "select * from usertable where username = '$name' && password = '$pass' && category='$cat'";
$result= mysqli_query($con,$s);
$num =$result->num_rows;
if($num==1)
{
    if ($cat=='Teacher')
    {
    header('location:http://localhost/webserver_BETA/indexTeachers.html');
    $_SESSION['firstname'] = $fname;
    $_SESSION['secondname'] = $sname;
    }
    if($cat=='Student')
    {
    header('Location:http://localhost/Webserver_BETA/indexStudents.html');
    $_SESSION['firstname'] = $fname;
    $_SESSION['secondname'] = $sname;
    }
}
if($num!=1)
{
    header('Location:http://localhost/Webserver_BETA/sign_in_fail.html');  
}
?>