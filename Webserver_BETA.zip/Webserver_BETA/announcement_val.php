<?php
session_start();
$con = mysqli_connect('localhost','root','');
if(!$con){
}
mysqli_select_db($con,'userregistration');
$announcement=$_POST['announcement'];
$fname=$_SESSION['firstname'];
$sname=$_SESSION['secondname'];

$reg = "insert into  announcements (fname , sname , announcement) values ('$fname' ,'$sname' , '$announcement')";
mysqli_query($con , $reg);

header('location:http://localhost/webserver_BETA/add_announcement_success.html');
?>