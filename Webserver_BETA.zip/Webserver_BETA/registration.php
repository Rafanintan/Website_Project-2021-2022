<?php
session_start();
$con = mysqli_connect('localhost','root','');
if(!$con){
}
mysqli_select_db($con,'userregistration');
$name=$_POST['user'];
$pass=$_POST['password'];
$mname=$_POST['prim_name'];
$sname=$_POST['sec_name'];
$cat=$_POST['category'];
$s= "select * from usertable where username = '$name'";
$result= mysqli_query($con,$s);
$num =$result->num_rows;
if($num>=1)
{
    header('Location:http://localhost/Webserver_BETA/registerfail.html');
}
else
{
    $reg = "insert into  usertable (username , password , prim_name , sec_name , category) values ('$name' , '$pass' , '$mname' , '$sname' , '$cat')";
    mysqli_query($con , $reg);
    echo file_get_contents("success_register.html");
}
?>