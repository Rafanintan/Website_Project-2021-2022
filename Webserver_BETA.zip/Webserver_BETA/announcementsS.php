<table>
<?php
$conn = mysqli_connect('localhost','root','','userregistration');
$sql = "SELECT * FROM announcements";
$result = $conn->query($sql);
$link_address2 = 'indexStudents.html';
echo "<a href='".$link_address2."'>UNIVERSITY OF PELOPONNESE</a>";
echo "<br><br><br><br>";
echo"|ANNOUNCEMENTS|";
echo " ";
echo "<a href='".$link_address2."'>Back To Home Page</a>";
if($result->num_rows > 0)
{
    echo "<td><br><br></td>";
    while($row = $result-> fetch_assoc())
    {
        echo "<td><br></td>";
        echo "<tr><td>" . $row["fname"] . "</td><td>" . $row["sname"] . "</td><td>" ."</td></tr>";
        echo "<tr><td>" . $row["announcement"]. "</td></tr>";
    }
}
else
{
    echo "<td><br><br></td>";
    echo "No Results";
}
?>
</table>