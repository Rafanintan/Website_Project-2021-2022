<?php

echo "<table><th> table heading</th><tr><td>table data</td></tr></table>"; 



?>